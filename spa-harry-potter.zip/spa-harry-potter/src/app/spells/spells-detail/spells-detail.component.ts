import { Component } from '@angular/core';

@Component({
  selector: 'app-spells-detail',
  standalone: true,
  imports: [],
  templateUrl: './spells-detail.component.html',
  styleUrl: './spells-detail.component.css'
})
export class SpellsDetailComponent {

}
